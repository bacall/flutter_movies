package com.example.cinemapedia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
